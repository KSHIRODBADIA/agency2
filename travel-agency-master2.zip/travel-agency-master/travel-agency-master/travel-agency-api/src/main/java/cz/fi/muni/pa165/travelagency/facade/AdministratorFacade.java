package cz.fi.muni.pa165.travelagency.facade;

/**
 *
 * @author 
 */
public interface AdministratorFacade extends UserFacade {
    
}
